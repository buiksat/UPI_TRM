# GPT Pro paper-review prompt

Act as an independent, highly skeptical ICLR reviewer and mathematical proof
auditor. Review the attached `main.pdf` as the current anonymous submission.

Read the entire 38-page PDF, including every proof, appendix, table,
limitation, and experiment description. The PDF is the only supplied evidence.
Do not assume that code, logs, checkpoints, per-seed artifacts, or missing
experiments exist. When a claim requires evidence not present in the PDF, label
it exactly `not verifiable from supplied evidence`.

## 1. Mathematical correctness

Audit Theorem 6.1 and all dependent corollaries:

- finite/countable versus measurable-space scope;
- quantifiers, frozen policies, initialization, boundedness, norms, closure,
  and absorbing-state conventions;
- finite-reference decomposition and recurrent path-length bound;
- finite-`m` geometric specialization and the `m -> infinity` limit;
- every factor involving `gamma`, `K`, and the residual norm.

Audit Theorem 6.5 line by line:

- exact CPI constants and occupancy argument;
- exact statewise centering and exact probability-space mixture assumptions;
- all approximation defects and factors of `gamma`, `alpha`, and
  `(1-gamma)`.

Audit the persistent-latent augmented-MDP construction, clock-complete state,
initial law, transition kernel, absorbing boundary, direct residual
certificate, and separation from optional slow-drift assumptions. Identify
hidden assumptions, circular arguments, invalid limits, support issues,
dimension mismatches, or inconsistent policy dependencies. Do not treat the
triangle inequality itself as a novelty contribution.

## 2. Claim and evidence alignment

Check every theoretical and empirical claim made by the PDF. In particular,
verify that the manuscript clearly states:

- the historical 57.4% UPI--TRM result is in-sample;
- the PPO comparison is not common-pool or interaction matched;
- the theory-aligned episodic endpoint is 0% and which policy was evaluated;
- no sample-efficiency conclusion follows from unmatched budgets;
- finite-batch diagnostics are not uniform theorem certificates;
- clamping is contraction-oriented rather than a global contraction proof;
- projection is a composite intervention where applicable;
- planned experiments are not described as completed results;
- the finite-MDP calculation is a numerical certificate, not an empirical
  discovery.

Recompute any number that can be recomputed from values printed in the PDF.
For every number that cannot be independently checked, state exactly what raw
evidence would be required.

## 3. ICLR assessment

Assess mathematical correctness, novelty, significance, empirical strength,
clarity, reproducibility, limitations, and likely reviewer objections. Decide
whether the analytical framing is sufficiently novel given the empirical
scope. Check whether the first two pages accurately communicate the
contribution and its limitations.

## Required response

Return these sections:

A. Verdict: `APPROVE`, `APPROVE WITH NON-BLOCKING FOLLOW-UPS`, or
`REQUEST CHANGES`.

B. Blocking correctness issues, ordered by severity.

C. Major reviewer concerns.

D. Minor issues and presentation fixes.

E. Claim-by-claim audit table with columns `claim`, `required condition`,
`evidence in PDF`, `recomputation`, and `status`.

F. Exact proposed textual edits, quoting the current PDF text where possible.

G. Missing experiments ranked by expected acceptance impact.

H. Overall ICLR score, confidence, dimension-level assessment, and concise mock
review.

For every finding, cite the PDF page and relevant section, theorem, equation,
figure, table, or appendix. Separate fatal errors from repairable writing or
evidence limitations. Do not invent results, citations, assumptions, or
execution outcomes.

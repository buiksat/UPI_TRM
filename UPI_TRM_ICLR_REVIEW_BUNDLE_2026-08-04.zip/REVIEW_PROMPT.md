# Independent ICLR Revision Review

Act as an independent, adversarial ICLR reviewer and mathematical proof auditor.

This bundle contains only:

- `paper.pdf`, the rendered manuscript;
- `paper.tex`, the exact `main.tex` source used for the manuscript body;
- this review prompt.

No code, checkpoints, raw results, audit reports, bibliography database, style
files, or supplement are supplied. Manuscript statements about tests,
artifacts, hashes, or experiments are claims rather than independent evidence.
Use exactly:

`not verifiable from supplied evidence`

for every claim that requires evidence absent from this bundle.

The PDF was built from the supplied TeX body at paper-repository commit
`3200a0e3ecd14d536eb1897975b9614087c2756b` using the repository's ICLR style,
bibliography, and figure dependencies. The body source was renamed from
`main.tex` to `paper.tex` for this bundle. Those external compilation
dependencies are intentionally omitted. Do not modify either paper file.

## First Check

Verify that the PDF and TeX represent the same revision by comparing the title,
abstract, algorithms, theorem statements, evidence-status table, limitations,
and conclusion. Independently report both SHA-256 hashes and the PDF page count.
If they differ materially, request changes and do not combine claims from the
two versions.

Expected bundle values are:

- `paper.tex`: `f1f7bb567578dbf1b4a3ab1d7c3db4cfdf3acee8b6e7fb9f818a8239550344e7`
- `paper.pdf`: `2fc2019ce41f526109922c8613f745e2d41222640ab26b73571183deea105f60`
- PDF page count: 32

## Repair Audit

Treat every expected repair as a hypothesis and verify it directly.

1. Persistent state is consistently `(x,y,z,h)`, with the pre-unroll latent,
   successor carry, remaining budget, terminal handling, and one absorber.
2. Main and appendix algorithms store clock-complete augmented transitions for
   persistent latents.
3. Projection is called contractive only when its stated modulus is below one.
4. The finite-reference theorem states its policy, closure, norm,
   initialization, boundedness, and absorbing assumptions locally.
5. The CPI theorem requires exact statewise centering, finite candidate bias,
   an exact pointwise probability mixture, and one fixed MDP. The stronger
   uniform error premise is only sufficient for its subsidiary bound.
6. The CPI strictness statement handles zero-error cases.
7. The slow-drift result has the correct initial-state quantifier and excludes
   the invalid `n=0` denominator case.
8. Finite-horizon recursions handle `h=0`, `K>h`, partial terminal blocks,
   `gamma=0`, and absorption without off-by-one errors.
9. Deployment TV and KL bounds have correct constants, support closure, and
   frozen-transition assumptions.
10. Exact mixture deployment is clearly separated from parameter interpolation
    or distillation.
11. Historical learned results, finite-batch diagnostics, and finite-MDP
    numerical tests are not presented as theorem validation or current
    comparative evidence.

## Evidence Honesty

Check that the manuscript:

- does not use the historical 57.4% result as current performance evidence;
- limits the episodic 0% record to what its retained metadata establishes;
- makes no held-out, interaction-matched, sample-efficiency, or superiority
  claim;
- does not call local Lipschitz or finite-batch measurements global
  certificates;
- identifies the bridge, matched PPO comparison, successful-checkpoint
  diagnostics, projection cross-design, and second domain as missing;
- does not claim absent files are submitted;
- distinguishes conditional proofs from measured theorem instantiation.

Do not penalize a claim merely for being negative or limited. Flag any sentence
whose wording exceeds its stated evidence.

## Required Response

1. **Verdict:** `APPROVE`, `APPROVE WITH NON-BLOCKING FOLLOW-UPS`, or
   `REQUEST CHANGES`.
2. **Blocking findings:** severity, PDF page or TeX line, evidence, impact, and
   the smallest safe correction.
3. **Repair disposition:** mark each of the 11 repairs `verified`, `partial`,
   `regressed`, or `not verifiable from supplied evidence`.
4. **Mathematical audit:** separate proof errors, missing assumptions,
   exposition issues, and valid conditional results whose premises were not
   measured.
5. **Claim-evidence table:** claim, required evidence, supplied evidence, and
   status.
6. **ICLR assessment:** score, confidence, novelty, correctness, clarity,
   significance, empirical support, and whether the conditional theory alone
   clears the acceptance threshold.
7. **Priority next work:** list only changes or experiments that could
   materially change the decision.

Cite a PDF page, theorem, equation, algorithm, table, or TeX line for every
material finding. Do not invent execution results, evidence, assumptions, or
citations.
